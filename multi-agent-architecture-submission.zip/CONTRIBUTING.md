Thank you for reviewing this project — here are quick notes for running, testing and submitting.

Getting started
- Create & activate a virtualenv: `python -m venv .venv && source .venv/bin/activate`
- Install dependencies: `pip install -r requirements.txt`

Run & test
- Run the pipeline (example): `python run_orchestrator.py --data "data/sample_input.csv"`
- Programmatic parallel run (chunked input): `python -c "from agents.core import run_full_pipeline; print(run_full_pipeline('data/sample_input.csv', chunk_size=1000, parallel_workers=4))"`
- Orchestrator parallel execution (graph-level): `python -c "from agents import Orchestrator; o=Orchestrator('data/sample_input.csv', max_workers=4); print(o.run())"`
- Run tests: `pytest -q` (expected: all unit tests pass)

Submission guidance
- Package: include the repo (or a zip) with `ARCHITECTURE.md`.
- Suggested email body is in `README.md` under "How to submit this (for assignment)".

Developer notes
- LLMs are optional and default to a deterministic `mock` provider for tests.
- To enable OpenAI tests locally, set `OPENAI_API_KEY` in your environment.

Contact / questions
- If you want me to prepare a zip or push a branch/PR, ask and I will do it for you.