# Architecture — Multi‑Agent Orchestrator (human‑friendly)

## TL;DR
This system is a hybrid agentic pipeline: LLMs do high‑level reasoning (plan, validate, reflect) while Python/pandas performs every numeric calculation. The Orchestrator coordinates a feedback loop: Plan → Execute → Validate → Reflect → (Retry or Replan).

## Core actors (what they do)
- Planner Agent — produces a structured, executable plan (list or graph of nodes). Can be LLM‑backed or deterministic.
- Executor / Tools — pure Python functions (load, assign quarter, aggregate, pivot, churn) — the truth engine for all math.
- Validator — deterministic checks (sums, schema) and optional LLM reviewer for logic/sense checks.
- Reflection — scores outcomes and recommends actions (accept, retry, replan, escalate).
- Memory Manager — short‑term run state + compressed long‑term summaries + optional semantic retrieval.
- Orchestrator — state machine that enforces plan execution, retries, idempotency and reflection actions.

## How autonomy actually works (concrete)
1. Planner emits nodes with `action`, `depends_on`, optional `params`, `validation_checkpoint`, and `retry_policy`.
2. Orchestrator executes nodes deterministically and logs outputs into short‑term memory.
3. Validator runs checks; Reflection inspects results and returns an action.
4. Orchestrator follows Reflection: retry node, call Planner to re‑plan, or escalate.

This is not a single LLM call — it is a closed loop with deterministic verification and controlled LLM reasoning.

## Memory: short vs long vs semantic
- Short‑term: immediate run context and step outputs (kept in memory only during execution).
- Long‑term: compressed summaries persisted for later retrieval and context (never raw data).
- Semantic: small deterministic vector store for retrieving relevant summaries to include in prompts.

## Reflection scoring & decision policy
Reflection returns a small scorecard (completeness, numeric_consistency, schema_validity). If numeric_consistency < threshold or schema checks fail, Reflection suggests `retry` or `replan`; Orchestrator enforces the decision.

## Token & scaling strategy
- `TokenEstimator` and `LLMClient` enforce budgets.
- Planner uses compressed summaries and semantic retrieval rather than raw rows.
- Data is streamed/chunked for very large files and aggregated incrementally.
- Parallelism & scalability: supports `parallel_workers` for chunk-level parallel processing and `Orchestrator(max_workers=...)` for graph-level parallel execution — both retain deterministic parity with sequential runs and are covered by unit tests.

## Resilience & observability
- Per‑node retry policies, exponential backoff and circuit breaker prevent repeated failures.
- Idempotency markers avoid duplicate side effects.
- Metrics and token logs are persisted to `outputs/` for traceability.

## Example planner node (practical)
```json
{
  "id": "agg_q1",
  "action": "aggregate_quarter_region",
  "depends_on": ["load"],
  "validation_checkpoint": "validate_quarterly",
  "retry_policy": {"max_attempts": 2}
}
```

## Sample failure → recovery flow (what reviewers can expect to see)
- Planner v1 (missing step) → Executor runs → Validator fails → Reflection requests `replan` → Planner v2 corrects plan → Orchestrator retries affected nodes → Validator passes → run completes.

## Tests & evidence
All important behaviors are unit‑tested (graph execution, chunking, retry, memory, semantic retrieval). See `tests/` for a replay of a replan scenario.

---

If you want a short slide or a one‑page PNG for the architecture section, I can generate that next.
