# Multi‑Agent Revenue & Churn Analyzer — polished demo

A compact, production‑minded implementation of a hybrid multi‑agent system that analyzes client revenue data, detects churn, generates insights, validates results, and self‑corrects when needed.

Why this repo exists
- It demonstrates a practical separation of concerns: **LLMs for reasoning, Python for computation**. That keeps results deterministic and auditable while enabling agentic behaviors (planning, reflection, re‑planning).
- Built to show real‑world constraints: token budgets, streaming/chunking for large files, memory summarization, retries, and observability.

Quick start (3 steps)
1) Prepare environment
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

2) Run tests (recommended)
   ```bash
   pytest -q
   # expected: all unit tests pass
   ```

3) Run the pipeline (example)
   ```bash
   # deterministic run (no LLM)
   python run_orchestrator.py --data "data/sample_input.csv"

   # with mock LLMs (planning/validation/reflection)
   python -c "from agents import Orchestrator; from agents.llm import LLMClient; o=Orchestrator('data/sample_input.csv', use_llm=True, planner_llm=LLMClient(provider='mock'), validator_llm=LLMClient(provider='mock')); print(o.run())"

   # programmatic: chunked + parallel workers (data chunking across threads)
   python -c "from agents.core import run_full_pipeline; print(run_full_pipeline('data/sample_input.csv', chunk_size=1000, parallel_workers=4))"

   # orchestrator-level parallelism (graph-level parallel execution)
   python -c "from agents import Orchestrator; o=Orchestrator('data/sample_input.csv', max_workers=4); print(o.run())"
   ```

What it does (short)
- Loads and normalizes Excel/CSV input
- Assigns quarters, aggregates revenue by region/country
- Computes per-client quarterly revenue and churn (lost/new clients, revenue deltas)
- Validates results deterministically and optionally via LLM review
- Reflects and can re‑plan or retry when validation fails
- Persists outputs and lightweight metrics in `outputs/`

Key design principles
- LLMs THINK; Python COMPUTES — never let an LLM perform numeric aggregation.
- Keep LLM context small: only send compressed summaries or retrieved snippets.
- Make runs idempotent and observable (metrics, token logs, failure traces).

Files & where to look
- `agents/` — core implementation (orchestrator, agents, tools, memory, and visualization helpers in `agents/visualize.py`).
- `tests/` — unit tests covering behavior and edge cases (including visualization smoke tests).
- `outputs/` — generated sample outputs after a run (PNG/HTML charts created by visualization helpers).

How to submit this (for assignment)
- Run `pytest -q` (all tests should pass).
- Zip the repository or push to a branch and include `ARCHITECTURE.md`.
- Email the repo/zip to the reviewer (see `CONTRIBUTING.md` for a suggested message).

Want me to package this for submission (ZIP + suggested email body) or push a PR? Say which and I’ll do it.
